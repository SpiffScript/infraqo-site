import { useState } from "react";

type PlanKey = "total" | "priority";

type PlanFeature = {
  title: string;
  description: string;
};

type Plan = {
  name: string;
  label: string;
  summary: string;
  idealFor: string;
  features: PlanFeature[];
  ctaLabel: string;
};

const PLANS: Record<PlanKey, Plan> = {
  total: {
    name: "TotalQo",
    label: "Core support plan",
    summary:
      "Everything a serious operator needs for stable, well-managed networks without overpaying for fluff.",
    idealFor:
      "Most small to mid-sized businesses that want predictable support and clean infrastructure.",
    features: [
      {
        title: "Remote support included",
        description:
          "Day-to-day troubleshooting and changes handled remotely within standard response windows.",
      },
      {
        title: "Proactive monitoring & patching",
        description:
          "Core devices monitored and kept current so you avoid preventable outages and security issues.",
      },
      {
        title: "Standard SLA response times",
        description:
          "Clear expectations around how quickly we respond, triage, and resolve issues.",
      },
      {
        title: "Preferred on-site rates",
        description:
          "When a visit is needed, you get discounted on-site work instead of surprise one-off pricing.",
      },
    ],
    ctaLabel: "Request TotalQo proposal",
  },
  priority: {
    name: "PriorityQo",
    label: "Premium support plan",
    summary:
      "For operators who want faster response, fewer surprises, and a true day-to-day technology partner.",
    idealFor:
      "Higher-demand environments or owners who never want to think about IT emergencies or nickel-and-dime billing.",
    features: [
      {
        title: "Priority response & faster SLAs",
        description:
          "Your tickets jump the line. Faster response, faster resolution, less downtime.",
      },
      {
        title: "Included / enhanced on-site coverage",
        description:
          "On-site work is included or heavily discounted, so you aren’t afraid to call when something feels off.",
      },
      {
        title: "After-hours & emergency coverage options",
        description:
          "Coverage designed for environments that can’t afford to wait until the next business day.",
      },
      {
        title: "Proactive reviews & planning",
        description:
          "Regular check-ins to plan upgrades, address risk, and keep your environment aligned with your operations.",
      },
    ],
    ctaLabel: "Request PriorityQo proposal",
  },
};

export default function SolutionPlans() {
  const [activePlan, setActivePlan] = useState<PlanKey>("total");
  const plan = PLANS[activePlan];

  const isPriority = activePlan === "priority";

  return (
    <section className="w-full pb-16 pt-4">
      <div className="mx-auto max-w-5xl px-4">
        {/* Section label + heading */}
        <div className="mb-6 max-w-3xl">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-sky-400">
            Managed support
          </p>
          <h2 className="mt-2 text-2xl font-semibold text-slate-50">
            Support plans built for operators who expect things done right.
          </h2>
          <p className="mt-3 text-sm text-slate-400">
            Two clear options. No gimmicks, no mystery pricing. Just structured
            support and clean expectations.
          </p>
        </div>

        {/* Accent line */}
        <div className="mb-6 h-[3px] w-28 bg-gradient-to-r from-sky-500 via-blue-500 to-sky-400" />

        {/* Plans container */}
        <div
          className="
            border border-slate-700 bg-slate-950/90
            shadow-[0_0_0_1px_rgba(15,23,42,0.9),0_24px_60px_rgba(0,0,0,0.75)]
          "
        >
          {/* Tabs */}
          <div className="flex border-b border-slate-800 bg-slate-950">
            <button
              type="button"
              onClick={() => setActivePlan("total")}
              className={`flex-1 px-4 py-3 text-left text-sm font-medium uppercase tracking-[0.14em] transition-colors
                ${
                  activePlan === "total"
                    ? "border-b-2 border-sky-400 bg-slate-900 text-slate-50"
                    : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-100"
                }`}
            >
              <span className="block text-[11px] text-slate-400">Plan 01</span>
              <span className="mt-0.5 block text-base font-semibold normal-case">
                TotalQo
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActivePlan("priority")}
              className={`flex-1 px-4 py-3 text-left text-sm font-medium uppercase tracking-[0.14em] transition-colors
                ${
                  activePlan === "priority"
                    ? "border-b-2 border-sky-400 bg-slate-900 text-slate-50"
                    : "text-slate-400 hover:bg-slate-900/60 hover:text-slate-100"
                }`}
            >
              <span className="block text-[11px] text-slate-400">Plan 02</span>
              <span className="mt-0.5 block text-base font-semibold normal-case">
                PriorityQo
              </span>
            </button>
          </div>

          {/* Active plan content with fade transition */}
          <div
            key={activePlan}
            className="
              grid gap-8 px-6 py-7 md:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]
              transition-opacity duration-300 ease-out
            "
          >
            {/* Left: overview */}
            <div
              className={`
                border border-slate-800 bg-slate-900/70 px-5 py-5
                ${isPriority ? "border-sky-500/70 shadow-[0_0_0_1px_rgba(56,189,248,0.4)]" : ""}
              `}
            >
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-sky-400">
                    {plan.label}
                  </p>
                  <h3 className="mt-1 text-lg font-semibold text-slate-50">
                    {plan.name}
                  </h3>
                </div>

                {isPriority && (
                  <span className="inline-flex items-center px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] border border-sky-500/70 bg-sky-500/10 text-sky-200">
                    Recommended
                  </span>
                )}
              </div>

              <p className="mt-3 text-sm text-slate-300">{plan.summary}</p>
              <p className="mt-4 text-xs text-slate-400">
                Ideal for: <span className="text-slate-200">{plan.idealFor}</span>
              </p>
            </div>

            {/* Right: features + CTA */}
            <div className="flex flex-col justify-between gap-4">
              <ul className="space-y-3">
                {plan.features.map((feature) => (
                  <li
                    key={feature.title}
                    className="border-b border-slate-800 pb-2 last:border-none last:pb-0"
                  >
                    <p className="text-sm font-medium text-slate-100">
                      {feature.title}
                    </p>
                    <p className="mt-0.5 text-xs text-slate-400">
                      {feature.description}
                    </p>
                  </li>
                ))}
              </ul>

              <div className="mt-5 flex justify-end">
                <button
                  type="button"
                  className="inline-flex items-center justify-center border border-sky-500 px-5 py-2 text-sm font-semibold uppercase tracking-[0.16em] text-sky-100 transition-colors hover:bg-sky-500 hover:text-slate-950"
                >
                  {plan.ctaLabel}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
