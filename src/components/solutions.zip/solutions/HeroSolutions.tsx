import React from "react";
import ConfigSimulation from "./ConfigSimulation";
import CtaButtonRow from "../ui/CtaButtonRow";

const HeroSolutions: React.FC = () => {
  return (
    <section className="solutions-hero-layout">
      <div className="solutions-hero-copy">
        <p className="solutions-eyebrow">SOLUTIONSQO</p>

        <h1 className="solutions-hero-heading">
          Structured support for teams who can&apos;t afford downtime.
        </h1>

        <p className="solutions-hero-body">
          InfraQo handles both project work and ongoing support. SolutionsQo is
          our framework for long-term reliability: clear expectations,
          structured plans, and operational stability from a partner who
          understands how your business actually runs.
        </p>

        <div className="solutions-hero-underline" />

        <p className="solutions-hero-subcopy">
          Two simple plans. One rule: no nickel-and-dime support, no mystery
          invoices, and no &quot;we&apos;ll get to it when we can.&quot;
        </p>
      </div>

      <ConfigSimulation />
    </section>
  );
};

export default HeroSolutions;
