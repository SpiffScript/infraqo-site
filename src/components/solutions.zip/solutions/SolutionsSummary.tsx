// src/components/solutions/SolutionsSummary.tsx
import React from "react";

const SolutionsSummary: React.FC = () => {
  return (
    <section className="solutions-lower">
      <div className="solutions-lower-grid">
        <div>
          <h2 className="text-xl font-semibold text-slate-50">
            Projects + ongoing support, on purpose.
          </h2>
          <p className="mt-3 text-sm text-slate-300">
            Most providers either want to sell one-off installs or lock you into
            bloated contracts. SolutionsQo is built for operators who need both:
            clean project work and predictable support after the dust settles.
          </p>
          <ul className="mt-4 space-y-2 text-sm text-slate-300">
            <li>
              • Use InfraQo for one-time cabling, Wi-Fi, camera, or network
              installs.
            </li>
            <li>
              • Layer on TotalQo or PriorityQo when you&apos;re ready for
              structured, ongoing support.
            </li>
            <li>
              • Keep uptime, documentation, and accountability under one roof.
            </li>
          </ul>
        </div>

        <aside className="solutions-card rounded-none p-6 sm:p-7">
          <p className="text-xs font-semibold tracking-[0.25em] text-sky-300 uppercase">
            Why SolutionsQo exists
          </p>
          <p className="mt-3 text-sm text-slate-200">
            A good install is only half the story. The rest is how issues are
            handled, how changes are made, and whether someone is paying
            attention to what your environment is doing over time.
          </p>
          <p className="mt-3 text-sm text-slate-200">
            SolutionsQo formalizes that attention: response times, process,
            planning, and what &quot;done right&quot; looks like when something
            breaks at 2 PM on a Friday.
          </p>
        </aside>
      </div>
    </section>
  );
};

export default SolutionsSummary;
